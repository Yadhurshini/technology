<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $first_name = $_POST['fname'];
    $user_name = $_POST['Uname'];
    $E_mail = $_POST['Email'];
    $phone_no = $_POST['phoneNumber'];
    $password = $_POST['password'];
    $Confirmpassword = $_POST['confirm_password'];

    // Validate input
    if (!empty($E_mail) && !empty($password) && $password === $Confirmpassword && !is_numeric($E_mail)) {
        
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Use prepared statements to prevent SQL injection
        $query = "INSERT INTO form (fname, Uname, Email, PhoneNumber, Password, Confirm_password) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param("ssssss", $first_name, $user_name, $E_mail, $phone_no, $hashed_password, $hashed_password);

        // Execute the statement
        if ($stmt->execute()) {
            // Success message
            echo "<script type='text/javascript'>alert('Successfully Registered')</script>";
        } else {
            // Error message
            echo "<script type='text/javascript'>alert('Error: " . $stmt->error . "');</script>";
        }

        // Close the statement
        $stmt->close();
    } else {
        // Validation error message
        echo "<script type='text/javascript'>alert('Please enter valid information or make sure passwords match.')</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register and Login</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="register.css">

</head>
<body>
    <script src="register.js"></script>
    <header>
            <div class="navbar">
              <label class="logo">MITHILA PHARMACY</label>
                </div>
            </header>

    <div class="container">
        <center>
        <h1>Create Your Online Account</h1>
        <br>
        <p>Already you have an account?  <a href="login.php">login</a>
     </p>
    </center>
    <br>
       <form action="register.php" method="POST">
        <div class="user-details">
            <div class="input-box">
                <span class="details">Full name</span>
                <input type="text" name="fname" placeholder="Enter your name" required>
            </div>
            <div class="input-box">
                <span class="details">User name</span>
                <input type="text" name="Uname" placeholder="Enter your user name" required>
            </div>
            <div class="input-box">
                <span class="details">Email </span>
                <input type="email" name="Email" placeholder="Enter your email" required>
            </div>
            <div class="input-box">
                <span class="details">Phone Number</span>
                <input type="text"  name="phoneNumber" placeholder="Enter your number" required>
            </div>
            <div class="input-box">
                <span class="details">Password</span>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>
            <div class="input-box">
                <span class="details">Confirm password</span>
                <input type="password" name="confirm_password" placeholder="confirm your password" required>
            </div>
        </div>
        
        <div class="button">
            <button class="button">Register</button>
            <a href="login.php" class="login-link"></a>
        </div>
       </form>
    </div>
<footer>
    <center>
    <p>© Mithila Online Pharmacy, All Right Reserved</p>
</center>
</footer>
</body>
</html>