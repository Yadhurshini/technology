// Function to remove item from cart and update the total
function updateCart() {
  const cartBody = document.getElementById('cart-body');
  const rows = cartBody.querySelectorAll('tr');
  let totalPrice = 0;

  // Calculate the total price
  rows.forEach(row => {
      const subtotal = row.querySelector('td:nth-child(4)').textContent;
      const subtotalValue = parseFloat(subtotal.replace('Rs. ', ''));
      totalPrice += subtotalValue;
  });

  // Update the total price in the table footer
  document.getElementById('total-price').textContent = `Rs. ${totalPrice}`;
}

// Function to handle removing items from the cart
function removeItem(event) {
  const buttonClicked = event.target;
  const row = buttonClicked.closest('tr');  // Find the row of the clicked button
  row.remove();  // Remove the row

  // Update the total after removing the item
  updateCart();
}

// Attach event listeners to all remove buttons
const removeButtons = document.querySelectorAll('.remove-btn');
removeButtons.forEach(button => {
  button.addEventListener('click', removeItem);
});

// Initialize the cart total on page load
window.onload = updateCart;
