
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pharmacy</title>
    <link rel="stylesheet" href="pha.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    
</head>
<body>
   
    <header>
        <div class="navbar">
            
            <label class="logo">MITHILA</label>
            
        <ul>
            <li class="active"><a href="index.html">Home</a></li>
            <li><a href="category.html">category</a></li>
            <li><a href="About Us.html">About Us</a></li>
            <li><a href="help.html">help</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="Register.php">Register</a></li>
            
        </ul>
        </div>
        
    </header>
    
    <div class="content">
        <h1>WELCOME<br><span>TO OUR MITHILA PHARMACY</span></h1><br><br>
        <p class="par">At mithila pharmacy, your health and well-being are our top priorities. We are committed to providing you with the highest quality pharmaceutical care in a warm, welcoming environment. Our experienced pharmacists and friendly staff are here to offer personalized services, expert advice, and a wide range of health products to meet all your needs.

            Whether you're managing a chronic condition, seeking advice on over-the-counter medications, or looking for wellness products, we are dedicated to helping you achieve your health goals. Our pharmacy offers convenient prescription services, medication counseling, and health screenings to ensure that you and your loved ones receive the best possible care.
            
            Thank you for choosing mithila pharmacy as your trusted healthcare partner. We look forward to serving you and your family with the care and attention you deserve.</p>
        <br>
         <center>
        <button class="cn"><a href="register.php">JOIN US</a></button>
    </center>
    </div>
    <br>
    <br>
<center>
    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Our Services<div class="underline"><span></span></div></h4>
                <ul>
                    <li><a href="#">pharmacy management</a></li>
                    <li><a href="#">order online</a></li>
                    <li><a href="#">loyality program</a></li>
                    <li><a href="#">pharmacy support</a></li>
                    <li><a href="#">pharmacy support</a></li>
                    
                </ul>
            </div>
            <div class="footer-col">
                <h4>Quick Access<div class="underline"><span></span></div> </h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">FAQs</a></li>
                    <li><a href="#">contact Us</a></li>
                    <li><a href="#">terms & coditions</a></li>
                    <li><a href="#">privacy policy</a></li>
                    
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contact Us<div class="underline"><span></span></div></h4>
                <ul>
                    <li><a href="#">No 23,LOP Head office, High level Road,Kottawa</a></li>
                    <li><a href="#">+94717810425</a></li>
                    <li><a href="#">info@mithilaonlinepharmacy.com</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>follow us<div class="underline"><span></span></div></h4>
                <div class="social-link">
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
        </center>
        <br><br>
        <center>
        <p>© Mithila Online Pharmacy, All Right Reserved.</p>
        
        </center>
    </footer>
</body>

</html>

