<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $E_mail = $_POST['Email']; // Accessing email
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : ''; // Check if it exists

    // Login logic without the confirmation password
    if (!empty($E_mail) && !empty($confirm_password) && !is_numeric($E_mail)) {
        // SQL query to check the user
        $query = "SELECT * FROM form WHERE email = '$E_mail' LIMIT 1"; 
        $result = mysqli_query($con, $query);

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $user_data = mysqli_fetch_assoc($result);
                // Check the password
                if ($user_data['password'] == $confirm_password) { // Ensure this matches your database
                    echo "<script type='text/javascript'>alert('Login Successful');</script>";
                    echo "<script type='text/javascript'>window.location.href='category.html';</script>";
                    $_SESSION['user_email'] = $user_data['Email']; // Store user email in session
                    die;

                    }
                 }
        }
        
        echo "<script type='text/javascript'>alert('Wrong username or password');</script>"; // Error message
    } else {
        echo "<script type='text/javascript'>alert('Wrong username or password');</script>"; // Error message
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
</head>
<body>
    <header>
        <div class="navbar">
            <label class="logo">ONLINE HEALTHCARE</label>
        </div>
    </header>
    <center>
        <section class="container form">
            <div class="form login">
                <div class="form-container">
                    <h1>WELCOME BACK</h1>
                    <p>New to Healthcare? <a href="register.php">Sign Up</a></p>

                    <form action="login.php" method="POST">
                        <div class="field input-field">
                           <input type="text" name="Email" required placeholder="Username or Email">
                        </div>

                        <div class="field input-field">
                            <input type="password" name="confirm_password" required placeholder="Password">
                        </div>

                        <div class="form-link">
                            <a href="#" class="forgot-pass">Forgot password?</a>
                        </div>

                        <div class="field button-field">
                            <button type="submit">Login</button>
                        </div>

                        <?php if (!empty($error_message)): ?>
                            <div class="error-message">
                                <p style="color: red;"><?php echo $error_message; ?></p>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </section>
    </center>
    <footer>
        <center>
            <p>© Mithila Online Pharmacy, All Rights Reserved</p>
        </center>
    </footer>
</body>
</html>
