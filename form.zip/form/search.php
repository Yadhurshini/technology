<?php
// Example search.php backend code
if (isset($_POST['searchTerm'])) {
    $searchTerm = strtolower($_POST['searchTerm']);

    // Sample products array (you'd replace this with your database query)
    $products = [
        ['name' => 'Antibiotics', 'price' => 250, 'image' => '384891.jpeg'],
        ['name' => 'Antidepressants', 'price' => 500, 'image' => 'imagesss.jpeg'],
        // Add more products here...
    ];

    // Filter products based on search term
    $filteredProducts = array_filter($products, function($product) use ($searchTerm) {
        return strpos(strtolower($product['name']), $searchTerm) !== false;
    });

    // Display filtered products
    foreach ($filteredProducts as $product) {
        echo '<div class="product">';
        echo '<img src="' . $product['image'] . '" alt="">';
        echo '<h3>' . $product['name'] . '</h3>';
        echo '<div class="price">RS.' . $product['price'] . '</div>';
        echo '</div>';
    }
}
?>
