// Assuming the previous code in category.js remains unchanged

document.querySelector('.search-btn').addEventListener('click', function() {
    const searchTerm = document.querySelector('.search-bar').value;

    // Send search term to PHP backend using AJAX
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "search.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Assuming the server returns the filtered products as HTML
            document.querySelector('.container').innerHTML = xhr.responseText;
        }
    };
    xhr.send(`searchTerm=${searchTerm}`);
});

function uploadPrescription() {
    const fileInput = document.getElementById('prescription-file');
    const message = document.getElementById('upload-message');

    // Clear previous message
    message.textContent = '';
    message.classList.remove('success', 'error'); // Remove previous classes

    if (fileInput.files.length === 0) {
        message.textContent = 'Please select a file to upload.';
        message.classList.add('error'); // Add error class
        message.style.display = 'block'; // Show the message
        return;
    }

    const file = fileInput.files[0];

    // Show a success message for now
    message.textContent = `Successfully uploaded: ${file.name}`;
    message.classList.add('success'); // Add success class
    message.style.display = 'block'; // Show the message

    // AJAX code to send the file to the server (uncomment when ready)
    /*
    const formData = new FormData();
    formData.append('prescription', file);

    fetch('your-upload-url', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        message.textContent = 'Upload successful!';
        message.classList.add('success'); // Add success class
        message.style.display = 'block'; // Show the message
    })
    .catch(error => {
        message.textContent = 'Upload failed. Please try again.';
        message.classList.add('error'); // Add error class
        message.style.display = 'block'; // Show the message
    });
    */
}



// Add event listener for the upload button
document.querySelector('.upload-prescription-btn').addEventListener('click', uploadPrescription);
function toggleUploadForm() {
    const form = document.getElementById('upload-prescription-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}